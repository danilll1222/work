<?php

$data = implode("\n", $_POST);

$domain = $_SERVER['HTTP_HOST'];
$to = "lead@".$domain; 
$subject = "Lead";
$message = $data;
$headers = "From: sender@".$domain;

if(mail($to, $subject, $message, $headers)) {
    //echo "Письмо успешно отправлено!";
}

?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VoidVerse | Request accepted!</title>
        <meta property="og:title" content="VoidVerse | Request accepted!" />
        <meta property="og:image" content="logodesign.svg"/>
        
        <meta property="og:description" content="VoidVerse | Request accepted!">
        <meta name="description" content="VoidVerse | Request accepted!">
  

        <link rel="shortcut icon" href="logodesign.svg" type="image/x-icon">
        <link href='https://fonts.googleapis.com/css2?family=Reddit+Mono:wght@200..900&display=swap' rel="stylesheet">
        <link href='https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap' rel="stylesheet">

        <style>
        body{
        font-family: 'Reddit Mono', sans-serif !important;
        direction: ltr;
        font-size: 1em;
        line-height: 1.4;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
        background-color: rgb(238 238 227);
        }
      button {
        word-wrap: break-word; 
      }
        a {
        text-decoration: none;
        }
        h2 {
          font-size: 32px;
          color: rgb(45 45 45);
        }

        .container {
        padding: 0;
        margin: 0 auto;
        box-sizing: border-box;
        }

       .padding-style {
       padding: 29px 0;
        }
        img {
        max-width: 100%;
        height: auto;
        margin: auto;
        }

        .button-1 {
    font-size: 18px;
    display: inline-block;
    outline: 0;
    border: 0;
    cursor: pointer;
    will-change: box-shadow,transform;
    background: radial-gradient( 100% 100% at 100% 0%, #89E5FF 0%, #5468FF 100% );
    box-shadow: 0px 0.01em 0.01em rgb(45 35 66 / 40%), 0px 0.3em 0.7em -0.01em rgb(45 35 66 / 30%), inset 0px -0.01em 0px rgb(58 65 111 / 50%);
    padding: 0 2em;
    border-radius: 0.3em;
    color: #fff;
    height: 2.6em;
    text-shadow: 0 1px 0 rgb(0 0 0 / 40%);
    transition: box-shadow 0.15s ease, transform 0.15s ease;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .button-1:hover {
    box-shadow: 0px 0.1em 0.2em rgb(45 35 66 / 40%), 0px 0.4em 0.7em -0.1em rgb(45 35 66 / 30%), inset 0px -0.1em 0px #3c4fe0;
    transform: translateY(-0.1em);
  }
  
  .button-1:active {
    box-shadow: inset 0px 0.1em 0.6em #3c4fe0;
    transform: translateY(0em);
  }
.button-2 {
  align-items: center;
  appearance: none;
  background-color: #FCFCFD;
  border-radius: 4px;
  border-width: 0;
  box-shadow: rgba(45, 35, 66, 0.2) 0 2px 4px,rgba(45, 35, 66, 0.15) 0 7px 13px -3px,#D6D6E7 0 -3px 0 inset;
  box-sizing: border-box;
  color: #36395A;
  cursor: pointer;
  display: inline-flex;
  font-family: "JetBrains Mono",monospace;
  height: 48px;
  justify-content: center;
  line-height: 1;
  list-style: none;
  overflow: hidden;
  padding-left: 16px;
  padding-right: 16px;
  position: relative;
  text-align: left;
  text-decoration: none;
  transition: box-shadow .15s,transform .15s;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  will-change: box-shadow,transform;
  font-size: 18px;
}
  .button-2:link,
  .button-2:visited {
 text-transform: uppercase;
 text-decoration: none;
 color: rgb(27, 27, 27);
 padding: 10px 30px;
 border: 1px solid;
 border-radius: 1000px;
 display: inline-block;
 transition: all .2s;
 position: relative;
}

.button-2:hover {
 transform: translateY(-5px);
 box-shadow: 0 10px 20px rgba(27, 27, 27, .5);
}

.button-2:active {
 transform: translateY(-3px);
}

.button-2::after {
 content: "";
 display: inline-block;
 height: 100%;
 width: 100%;
 border-radius: 100px;
 top: 0;
 left: 0;
 position: absolute;
 z-index: -1;
 transition: all .3s;
}

.button-2:hover::after {
 background-color: rgb(0, 238, 255);
 transform: scaleX(1.4) scaleY(1.5);
 opacity: 0;
}

.button-3 {
  align-items: center;
  appearance: none;
  background-color: #FCFCFD;
  border-radius: 4px;
  border-width: 0;
  box-shadow: rgba(45, 35, 66, 0.2) 0 2px 4px,rgba(45, 35, 66, 0.15) 0 7px 13px -3px,#D6D6E7 0 -3px 0 inset;
  box-sizing: border-box;
  color: #36395A;
  cursor: pointer;
  display: inline-flex;
  font-family: "JetBrains Mono",monospace;
  height: 48px;
  justify-content: center;
  line-height: 1;
  list-style: none;
  overflow: hidden;
  padding-left: 16px;
  padding-right: 16px;
  position: relative;
  text-align: left;
  text-decoration: none;
  transition: box-shadow .15s,transform .15s;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  white-space: nowrap;
  will-change: box-shadow,transform;
  font-size: 18px;
 }
 
 .button-3:focus {
  box-shadow: #D6D6E7 0 0 0 1.5px inset, rgba(45, 35, 66, 0.4) 0 2px 4px, rgba(45, 35, 66, 0.3) 0 7px 13px -3px, #D6D6E7 0 -3px 0 inset;
 }
 
 .button-3:hover {
  box-shadow: rgba(45, 35, 66, 0.3) 0 4px 8px, rgba(45, 35, 66, 0.2) 0 7px 13px -3px, #D6D6E7 0 -3px 0 inset;
  transform: translateY(-2px);
 }
 
 .button-3:active {
  box-shadow: #D6D6E7 0 3px 7px inset;
  transform: translateY(2px);
 }

 .button-4 {
  position: relative;
  background-color: rgb(79, 56, 61);
  border-radius: 5px;
  box-shadow: rgb(65, 22, 38) 0px 4px 0px 0px;
  padding: 15px;
  background-repeat: no-repeat;
  cursor: pointer;
  box-sizing: border-box;
  width: 154px;
  height: auto;
  color: #fff;
  border: none;
  font-size: 20px;
  transition: all 0.3s ease-in-out;
  z-index: 1;
  overflow: hidden;
}

.button-4::before {
  content: "";
  background-color: rgb(144, 72, 88);
  width: 0;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  transition: width 700ms ease-in-out;
  display: inline-block;
}

.button-4:hover::before {
  width: 100%;
}

.button-5 {
  padding: .9rem 1.5rem;
  border: .2rem solid #443;
  border-radius: 95% 4% 97% 5% / 4% 94% 3% 95%;
  color: #443;
  background: none;
  cursor: pointer;
  margin-top: 1rem;
  font-size: 14px;
  transition: all .2s linear;
}

.button-5:hover {
  border-radius: 4% 95% 6% 95% / 95% 4% 92% 5%;
  border: .2rem dashed #443;
}



        .flex-column {
        display: flex;
        flex-direction: column-reverse;
        }
        .header {
        padding: 32px;
        background-color: rgb(45 45 45);
        box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
        }
        .header-container {
    display: flex;
    flex-direction: row-reverse;
    justify-content: space-between;
    align-items: center;
        }
        .header-logo {
        height: auto;
        display: flex;
    align-items: center;
    flex-direction: row;
        }
        .img-logo {
        margin: 10px;
        }
        .logo-text {
        color: rgb(176, 168, 168);
        font-size: 32px;
        }
        .logo-text:hover{
            color: rgb(255, 255, 255);
        }
        .navbar-wrap-button {
        display: flex;
    align-items: center;
    flex-direction: row;
        }
    
        .nav-list{
        display: flex;
    flex-direction: row;
    padding-left: 0;
        }
        .nav-item {
          list-style: none;
        }
       
        .nav-link {
            margin: 0 13px;
            color: rgb(255, 255, 255);
            font-size:  16px;
        }
        .nav-link:hover {
            color: rgb(134 126 126); 
        }
        .head-container {
          display: flex;
    flex-direction: row-reverse;
    justify-content: space-evenly;
    align-items: center;
        }
        .header-img-box{
          text-align: center;
          flex: 1;
        }
        .header-img {
    width: 500px;
    height: 600px;
    border-top-left-radius: 250px;
    border-top-right-radius: 250px;
    object-fit: cover;
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
        }
        .head-title {
          font-size: 32px;
          text-align: center;
        }
        .hero-button {
          text-align: center;
        }
        .head-title-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
        }
        .head-title-btn div {
          margin: 15px 0;
        }
        
        .header-img-two {
          width: 400px;
    height: 400px;
    object-fit: cover;
    border-radius: 300px;
    position: relative;
    /* top: 50px; */
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
        }
        .about-us-container {
          display: flex;
          flex-direction: row-reverse;
          padding: 50px 0;
          align-items: center;
        }
        .about-us-img {
          flex: 1;
          display: flex;
    text-align: center;
    align-items: center;
        }
        .about-us-img img{
          box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
          width: 500px;
          height: 500px;
          object-fit: cover;
        }
        .about-us-text {
          flex: 1;
          font-size: 20px;
          padding: 13px;
        }
.question-answer div h2 {
  text-align: center;
  padding: 15px;
}
  .book {
  position: relative;
  border-radius: 10px;
  margin: 20px;
  width: auto;
  height: auto;
  background-color: white;
  -webkit-box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
 
  -webkit-transform: preserve-3d;
  -ms-transform: preserve-3d;
  transform: preserve-3d;
  -webkit-perspective: 2000px;
  perspective: 2000px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  color: #000;
}

.cover {
  top: 0;
  position: absolute;
  background-color: lightgray;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  cursor: pointer;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
  -webkit-transform-origin: 0;
  -ms-transform-origin: 0;
  transform-origin: 0;
 
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
}
.cover p {
  display: flex;
    text-align: center;
    flex-direction: row;
    align-items: center;
}

.book:hover .cover {
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
  -webkit-transform: rotatey(-85deg);
  -ms-transform: rotatey(-85deg);
  transform: rotatey(-85deg);
}

.book p {
  padding: 15px;
  font-size: 20px;
  font-weight: bolder;
}
.main-image {
  text-align: center; 
  margin: 20px;
}
.main-image img {
  width: 100vh; 
  height: 100%;
}
.main-content {
  padding: 13px;
}
.container-price div {
  padding: 0 15px;
  color: #257A3E;
  font-size: 32px;
}


.tarif-service-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; 
}
.plan-card {
  background: #fff;
  width: 15rem;
  padding-left: 2rem;
  padding-right: 2rem;
  padding-top: 10px;
  padding-bottom: 20px;
  border-radius: 10px;
  border-bottom: 4px solid rgb(45 45 45);
  box-shadow: 0 6px 30px rgba(207, 212, 222, 0.3);
  transition: background-color 0.3s ease;
}
.plan-card:hover {
        background-color: lightgray; 
    }
.plan-card:hover .benefits-list li {
    transform: scale(1.1); 
}
.benefits-list li {
    transition: transform 0.3s ease; 
}

.plan-card h2 {
  margin-bottom: 15px;
  font-size: 27px;
  font-weight: 600;
}

.plan-card h2 span {
  display: block;
  margin-top: -4px;
  color: #4d4d4d;
  font-size: 12px;
  font-weight: 400;
}

.etiquet-price {
  position: relative;
  background: #257A3E;
  width: 16rem;
  margin-left: -0.65rem;
  padding: .2rem 1.2rem;
  border-radius: 5px 0 0 5px;
}

.etiquet-price p {
  margin: 0;
  padding-top: .4rem;
  display: flex;
  font-size: 1.9rem;
  font-weight: 500;
}

.etiquet-price div {
  position: absolute;
  bottom: -23px;
  right: 0px;
  width: 0;
  height: 0;
  border-top: 13px solid #257A3E;
  border-bottom: 10px solid transparent;
  border-right: 13px solid transparent;
}

.benefits-list {
  margin-top: 16px;
}

.benefits-list ul {
  padding: 0;
  font-size: 14px;
}

.benefits-list ul li {
  color: #4d4d4d;
  list-style: none;
  margin-bottom: .2rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}

.benefits-list ul li svg {
  fill: currentColor;
}
.benefits-list svg {
  width: 10%;
}
.benefits-list p {
  width: 90%;
}
.benefits-list ul li span {
  font-weight: 300;
}
.tarif-service {
  background-color: rgba(45, 45, 45, 0.433);
}
.tarif-service-container {
  display: flex;
    flex-direction: row;
    justify-content: space-evenly;
    align-items: flex-start;
}
.tarif-service-container h2 {
  padding: 15px;
}
.service-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.our-service-title {
  padding: 15px;
}
.our-service-items {
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
  gap: 30px;
} 
.our-service-box {
  display: flex;
  flex-direction: column-reverse;
  align-items: center;
  width: 450px;
  background-color: white;
  border-radius: 15px;
}
.our-service-box svg {
  margin: 15px;
  border: 1px solid rgb(238 238 227);
    padding: 20px;
    border-radius: 50px;
    color: white;
    background-color: rgb(238 238 227);
}

.our-service-img {
  width: 400px;
  height: 400px;
  object-fit: cover;
  border-radius: 300px;
  box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
}
.our-service-img:hover {
box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
}
.our-service-text {
  text-align: center;
  margin: 20px;
}
.contacts-form-container {
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.footer-contacts-text {
  flex: 1;
}
.footer-contacts {
  flex: 1;
  display: flex;
    padding: 10px;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
.footer-contacts ul {
  padding-left: 0;
  line-height: 3;
}
.formtext-footer {
  padding: 10px;
  text-align: center;
  color: rgb(78 76 76);
  font-size: 24px;
}
.footer-contacts-items a {
  color: rgb(45 45 45);
}
.footer-contacts-items li {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.footer-contacts-items svg {
  margin: 0 20px;
}
.form-footer {
  border-radius: 15px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 1;
  padding: 30px;
  margin: 0 20px;
  background-color: rgb(45 45 45 / 46%);
}
.form-footer label {
  color: white;
  margin: 10px 0;
}
.input-r57669801 {
  color: white;
 display: flex;
 padding:  7px 16px;
 margin:  7px 0;
 width: 90%;
 border: 1px solid white;
 background-color: rgb(45 45 45);
}
 .textarea-r57669801 {
  color: white;
 display: flex;
 padding:  7px 16px;
 margin:  7px 0; 
 width: 90%;
 border: 1px solid white;
 background-color: rgb(45 45 45);
}

 .form-check-label {
  color: #fff;
 }
 .com-checkbox {
  margin: 10px;
 }
 .form-check-label a {
color: rgb(255 166 0);
 }
 .form-footer button {
  margin: 10px 0 20px 0;
  width: 250px;
  overflow: hidden;
 }
 .footer-form-flex {
  display: flex;
  flex-direction: column;
  flex: 1;
 }
 .form-footer button:hover{
box-shadow: 4px 4px 3px 2px rgba(0, 0, 0, 0.3);
}  
.footer-logo-rights {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
}
.rights {
  background-color: rgb(45 45 45);
}
.footer-img-logo a{
  display: flex;
    align-items: center;
    flex-direction: row;
}
.nav-link-footer {
  margin: 0 12px;
    color: rgb(255, 255, 255);
    font-size: 17px;
}
.navbar-list-footer {
  list-style: none;
}
.footer-rights {
  gap: 13px;
  display: flex;
  flex-direction: column;

}
.formtext-footer {
  color: rgb(78 76 76);
    font-size: 24px;
}
.footer-conntacts-text {
  flex: 1;
}
.nav-list-footer {
  display: flex;
  flex-direction: column;
  gap: 13px;
list-style: none;
padding-left: 0;
}

        @media screen and (min-width: 480px) {
      .container {
        max-width: 480px;
      }
    }
    @media screen and (min-width: 768px) {
      .container {
        max-width: 768px;
      }
    }
    @media screen and (min-width: 1200px) {
      .container {
        max-width: 1200px;
      }
    }

    @media (max-width: 1199px){
    .header-container {
        flex-direction: column !important;
    }
    .header-img {
      width: 350px;
    height: 350px;
    }
    .header-img-two {
      width: 250px;
    height: 250px;
    top: 50px;
    }
    .contacts-form-container {
      flex-direction: column !important;
    }
    }
    @media (max-width: 800px) {
      .head-container,
      .about-us-container {
        flex-direction: column !important;
      }
    }
    @media (max-width: 500px) {
    .nav-list {
      flex-direction: column !important;
      align-items: center;
    }
    .about-us-img img{
          width: 350px;
          height: 350px;
    }
    .our-service-box {
      width: 300px;
    }
    .footer-logo-rights {
      flex-direction: column !important;
      align-items: flex-start;
    }
    }


    @media (max-width: 567px) {
      .tarif-service-container h2 {
        font-size: 22px;
      }
      .head-title p {
        font-size: 22px;
      }
      .privTitl {
        font-size: 22px;
      }
      .question-answer div h2 {
        font-size: 22px;
      }
      .priv-blop {
        padding: 10px !important;
      }
    }

    @media (max-width: 350px) {
.header-img {
  width: 320px;
  height: 320px;
}
.about-us-img img{
          width: 320px;
          height: 320px;
    }
    .plan-card {
      width: 200px;
    }
    .etiquet-price {
      width: 217px;
    }
    .footer-contacts-items li {
      flex-direction: column !important;
    }
   
    }
       
        </style>

        
        </head>
        <body class="txt--m6G26--style">
            <header class="header" id="top">
                <div class="header-container container">
                    <a href="./"> 
                        <div class="header-logo">
                          <img class="img-logo" src="logodesign.svg" style="width: 60px; ">
                          <div class="headline logo-text">VoidVerse</div>
                        </div>
                    </a>

                    <div class="navbar-wrap-button">
                        <nav class="navbar-wrap">
                          <ul class="nav-list">
                           
                                <li class="nav-item">
                                    <a class="nav-link" href="./">Home</a></li>
                           
                                <li class="nav-item">
                                    <a class="nav-link" href="./#ourservice">Our Services</a></li>
                            
                            
                          </ul>
                        </nav>
                      </div>

                </div>
            </header>

            <div class="padding-style">
              <div class="container">
                <div class="head-container">
                <div class="header-img-box">
                  <img class="header-img" src="gallery/0_art_gallery_zbot.jpg"/> 
                </div>

                <div class="head-title-btn">
                  <div class="head-title">
                      <p>Dear friends, welcome to the VoidVerse family! We know you love playing, and we're here to provide you with everything you need for your passion. Let us be a part of your gaming journey.</p>
                   </div>
                   

                  <div class="header-img-box-two">
                    <img class="header-img-two" src="gallery/1_art_gallery_zbot.jpg"/>
                  </div>
                </div>
              </div>
              </div>
            </div>

        


<style>
	* {
		padding: 0;
		margin: 0;
	}
	#mainWrapp-footer--YyI7C--section{
		margin: 0px;
		padding: 0px;
		font-family: 'Noto Sans Display', sans-serif;
		width: 100%;
		font-size: 16px;
		padding: 329px 0px;
	}
	.bodyClass1-footer--YyI7C--section{
		background: #f4f9f9;
		color: #ffffff;
	}
	.bodyClass2-footer--YyI7C--section{
		background: #fff;
		color: #fff;
	}
	.bodyClass3-footer--YyI7C--section{
		background: #fff;
		color: #111;
	}
	.wrapage-block-footer--YyI7C--section{
		background-size: 100%;
		width: 100%;
	}
	.box_main-footer--YyI7C--section{
		width: 100%;
		margin: 0 auto;
		text-align: center;
		display: flex;
		justify-content: center;
		align-self: center;
		align-items: center;
	}
	.box_main-footer--YyI7C--section h2{
		font-size: 24px;
		padding: 0px 0px 25px;
	}
	.box_main-footer--YyI7C--section p{
		font-weight: 500;
		font-size: 18px;
	}
	p{
		margin-bottom: 10px;
	}
	.mainBlock-footer--YyI7C--section{
		text-align: start;
	}
	.mainBlock-footer--YyI7C--section ul{
		text-align: start;
		padding: 20px;
		display: flex;
		flex-direction: column;
		gap: 15px;
	}
	.mainBlock-footer--YyI7C--section ul>li span{
		font-weight: bold;
	}
	.mainBlock-footer--YyI7C--section{
		max-width: 1059px;
		margin: 0 auto;
		padding: 40px;
		background: #7b7d008c;
		border-radius: 10px;
	}
	.mainBlock-footer--YyI7C--section .cBlock-footer--YyI7C--section{
		text-align: start;
	}

	.bodyClass3-footer--YyI7C--section .mainBlock-footer--YyI7C--section{
		background: none;
		border-top: 2px solid #f8f1f1;
		border-bottom: 2px solid #f8f1f1;
	}
	.bodyClass2-footer--YyI7C--section .mainBlock-footer--YyI7C--section{
		background: #160F30;
		color: #fff !important;
		box-shadow: 0px 0px 10px #160F30;
	}
	.bodyClass2-footer--YyI7C--section .mainBlock-footer--YyI7C--section p{
		color: #fff !important;
	}
	.bodyClass1-footer--YyI7C--section .mainBlock-footer--YyI7C--section{
		background: #122F14;
		color: #ffffff;
		border-left: 0px solid #342056;
	}
	.bodyClass1-footer--YyI7C--section .mainBlock-footer--YyI7C--section p{
		color: #ffffff !important;
	}
	.order-footer--YyI7C--section{
		font-size: 18px !important;
	}

	  @media screen and (max-width: 639px) {
		  .box_main-footer--YyI7C--section p{
			padding: 0px 15px;
		  }
		  .box_main-footer--YyI7C--section h2{
			  padding: 0px 10px 15px;
		  }
		.mainBlock-footer--YyI7C--section{
			padding: 15px;
		}


	}
	@media screen and (max-width: 480px) {
		#mainWrapp-footer--YyI7C--section{
			height: 100%;
		}
	}
</style>
<div class="bodyClass2-footer--YyI7C--section" id="mainWrapp-footer--YyI7C--section">


	<div class="wrapage-block-footer--YyI7C--section">
		<div class="box_main-footer--YyI7C--section">
			<div class="mainBlock-footer--YyI7C--section">
				<p>We're truly grateful for your outreach and the confidence you've placed in us. Your support empowers our dedicated team to enhance the caliber of our offerings continually.</p>
<p>Remember, your insights, feedback, and suggestions are invaluable to our growth and evolution. If there's anything on your mind or if you require assistance, please feel free to reach out. Our commitment is to be readily available to assist you.</p>
<p class="cBlock-footer--YyI7C--section">With heartfelt thanks and warm wishes!</p>
			</div>
		</div>
	</div>


</div>




     <section class="rights padding-style">
      <div class="container">

        <div class="footer-img-logo"> 
          <a href="./">
             <img class="img-logo"  src="logodesign.svg" style="width: 60px;"> 
              <div class="footer-logo-text">
               <div class="logo-text">VoidVerse</div>
             </div>
           </a>
       </div> 

       <div class="footer-logo-rights">
        <nav class="navbar-wrap-footer">
        <ul class="nav-list-footer">
         
              <li class="nav-item-footer">
                  <a class="nav-link-footer" href="./">Home</a></li>
         
              <li class="nav-item-footer">
                  <a class="nav-link-footer" href="./#ourservice">Our Services</a></li>
          
          
        </ul>
      </nav>

        <div class="footer-rights">
          <a class="nav-link-footer" href="privacy-agreement.html">Privacy policy</a>
          <a class="nav-link-footer" href="membershipTerms.html">Terms & Conditions</a>
          <a class="nav-link-footer" href="financialDisclaimer.html">Disclaimer</a>
        </div>
      </div>

      </div>

    </section>

    

        

</body>
</html>
